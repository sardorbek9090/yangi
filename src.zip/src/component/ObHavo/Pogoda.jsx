import React, { useState } from "react";
import { apiWeather } from "../../api/apiWeather";
import "./style.css";
function Pogoda(props) {
  const [query, setQuery] = useState("");
  const [weather, setWeather] = useState([]);

  let showdate= new Date()
  let displayTodaydate=showdate.getDate()+'/'+(showdate.getMonth()+1)+'/'+showdate.getFullYear();
  let dt=showdate.toDateString()
  let displaytime= showdate.getHours()+':'+showdate.getMinutes();

  const search = async (e) => {
    if (e.key === "Enter") {
      const data = await apiWeather(query);
      setWeather(data);
      setQuery("");
      console.log(data);
    }
  };

  return (
    <div className="main-container">
      <input
        type="text"
        placeholder="Country"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyPress={search}
      />
      {weather.main && (
        <div className="asosiy">
          <div className="blok2">
            <div className="box1">
              <div className="ocloc">
                <span style={{fontSize:'70px',fontWeight:'700'}}>{displaytime}</span>
               <div id="date">
               <span>{dt}</span>
               </div>
              </div>
            </div>
            <div className="box1">
              <h2 className="city-name country">
                <span>{weather.name}</span>
                <sup>{weather.sys.country}</sup>
              </h2>
            </div>
          </div>
          <div className="city">
            <div className="blok3">
              <div className="kulik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <h2 className="city-name" >Today</h2>
                  <div className="city-temp" style={{fontSize:'60px'}}>
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
              <div className="haftalik">
                <div className="info">
                  <img
                    src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
                    alt="weather-icon"
                  />
                </div>
                <div className="detailes">
                  <span className="city-name">
                    <span>{weather.name}</span>
                    <sup>{weather.sys.country}</sup>
                  </span>
                  <div className="city-temp">
                    {Math.round(weather.main.temp)}
                    <sup>&deg;C</sup>
                    {/* <p>{weather.weather[0].description}</p> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Pogoda;
