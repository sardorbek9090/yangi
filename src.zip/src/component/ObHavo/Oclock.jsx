import React from 'react';

function Oclock(props) {
    let showdate= new Date()
    let displayTodaydate=showdate.getDate()+'/'+(showdate.getMonth()+1)+'/'+showdate.getFullYear();
    let dt=showdate.toDateString()
    let displaytime= showdate.getHours()+':'+showdate.getMinutes();
    return (
        <div>
           {/* <input type="text" value={displayTodaydate} style={{background:'green'}} readOnly="true" /> */}
           {dt}- {displaytime}
        </div>
    );
}

export default Oclock;