import React from "react";
import Pogoda from "./component/ObHavo/Pogoda";
import Oclock from './component/ObHavo/Oclock'
import "./App.css";



function App(props) {


  return (
    <div>
      <Pogoda/>
      {/* <Wethe/> */}
     {/* <Blok/> */}
     {/* <Oclock/> */}
    </div>
  );
}

export default App;
